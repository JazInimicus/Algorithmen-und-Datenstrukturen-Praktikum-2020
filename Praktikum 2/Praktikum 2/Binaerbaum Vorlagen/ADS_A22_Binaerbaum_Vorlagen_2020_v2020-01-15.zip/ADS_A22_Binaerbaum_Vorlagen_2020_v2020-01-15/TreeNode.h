/*************************************************
* ADS Praktikum 2.2
* TreeNode.h
* Erweiterung um Hilfsattribute und -funktionen gestattet, wenn erforderlich.
*************************************************/
#pragma once
#include <string>

using namespace std;

class TreeNode{
	
	private:
		///////////////////////////////////////
		// Ihr Code hier:	
			

		//
		////////////////////////////////////
	
	public:
		///////////////////////////////////////
		// Ihr Code hier:
			


		//
		////////////////////////////////////
};
