/*************************************************
* ADS Praktikum 2.2
* main.cpp
*
*************************************************/
#define CATCH_CONFIG_RUNNER
#include <iostream>
#include "Tree.h"
#include "catch.h"

using namespace std;

	///////////////////////////////////////
	// Hilfsmethoden f�rs Men� hier:



	//
	///////////////////////////////////////
int main() {

	int result = Catch::Session().run();

	///////////////////////////////////////
	// Ihr Code hier:

	

	//
	///////////////////////////////////////
	system("PAUSE");

	return 0;
}
